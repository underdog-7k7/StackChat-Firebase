package com.example.vidplayer

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vidplayer.ui.theme.VidplayerTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VidplayerTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    video()
                }
            }
        }
    }
}


@Composable
fun video() {
    val context = LocalContext.current

    Column(
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(10.dp)
            .verticalScroll(rememberScrollState())

    ) {
        Row(horizontalArrangement = Arrangement.SpaceEvenly) {
            Text(
                text = "VALORANT",
                color = Color.Red,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Serif,
                fontSize = 35.sp,
                fontWeight = FontWeight.Bold
            )

            Image(
                painter = painterResource(id = R.drawable.valo),
                contentDescription = "valo",
                modifier = Modifier.size(45.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        //SAGE
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
                .height(160.dp),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 100.dp
            )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Image(
                    painter = painterResource(id = R.drawable.sagepfp),
                    contentDescription = "sage",
                    modifier = Modifier.size(100.dp)
                        .height(200.dp)
                        .width(100.dp)
                )

                Text(
                    text = "The Soul Giver",
                    color = Color.Blue,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(15.dp),
                )

            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { val intent = Intent(context, sage::class.java)
                    context.startActivity(intent)
                },
                colors = ButtonDefaults.buttonColors(Color.LightGray),
                modifier = Modifier
                    .size(width = 170.dp, height = 45.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Healing here!", fontSize = 20.sp, color = Color.Black)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        //REYNA
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
                .height(160.dp),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 100.dp
            )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Image(
                    painter = painterResource(id = R.drawable.reynapfp),
                    contentDescription = "reyna",
                    modifier = Modifier.size(100.dp)
                )

                Text(
                    text = "The Soul Taker",
                    color = Color.Magenta,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(15.dp),
                )

            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {val intent = Intent(context, reyna::class.java)
                    context.startActivity(intent) },
                colors = ButtonDefaults.buttonColors(Color.LightGray),
                modifier = Modifier
                    .size(width = 200.dp, height = 45.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Blinding here!", fontSize = 20.sp, color = Color.Black)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        // KJ
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
                .height(160.dp),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 100.dp
            )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Image(
                    painter = painterResource(id = R.drawable.killjoypfp),
                    contentDescription = "kj",
                    modifier = Modifier.size(100.dp)
                )

                Text(
                    text = "The Technician",
                    color = Color.Red,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(15.dp),
                )

            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {val intent = Intent(context, kj::class.java)
                    context.startActivity(intent) },
                colors = ButtonDefaults.buttonColors(Color.LightGray),
                modifier = Modifier
                    .size(width = 170.dp, height = 45.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Fixing here!", fontSize = 20.sp, color = Color.Black)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        //Cypher
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
                .height(160.dp),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 100.dp
            )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Image(
                    painter = painterResource(id = R.drawable.cypherpfp),
                    contentDescription = "cypher",
                    modifier = Modifier.size(100.dp)
                )

                Text(
                    text = "The Spotter",
                    color = Color.DarkGray,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(15.dp),
                )

            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {val intent = Intent(context, cypher::class.java)
                    context.startActivity(intent) },
                colors = ButtonDefaults.buttonColors(Color.LightGray),
                modifier = Modifier
                    .size(width = 170.dp, height = 45.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Hiding here!", fontSize = 20.sp, color = Color.Black)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        //Jett
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp)
                .height(160.dp),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 100.dp
            )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Image(
                    painter = painterResource(id = R.drawable.jetypfp),
                    contentDescription = "jett",
                    modifier = Modifier.size(100.dp)
                )

                Text(
                    text = "The Dasher",
                    color = Color.Black,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(15.dp),
                )

            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {val intent = Intent(context, jett::class.java)
                    context.startActivity(intent) },
                colors = ButtonDefaults.buttonColors(Color.LightGray),
                modifier = Modifier
                    .size(width = 170.dp, height = 45.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Flying here!", fontSize = 20.sp, color = Color.Black)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

    }
}


