package com.example.vit_20bct0142_youtube

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navArgument
import androidx.navigation.compose.rememberNavController
import coil.annotation.ExperimentalCoilApi
import coil.compose.rememberImagePainter
import com.example.vit_20bct0142_youtube.ui.theme.VIT_20BCT0142_YoutubeTheme
import com.google.api.client.googleapis.json.GoogleJsonResponseException
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.youtube.YouTube
import com.google.api.services.youtube.model.SearchListResponse
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VIT_20BCT0142_YoutubeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    AppContent(navController)
                }
            }
        }
    }
}

@Composable
fun YoutubeScreen(
    videoId: String,
    modifier: Modifier
) {
    AndroidView(factory = { context ->
        val view = YouTubePlayerView(context)
        val playerInitializer: YouTubePlayer.() -> Unit = { loadVideo(videoId, 0f) }
        view.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                super.onReady(youTubePlayer)
                youTubePlayer.playerInitializer()
            }
        })
        view
    })
}

data class VideoItem(
    val videoId: String,
    val title: String,
    val description: String,
    val thumbnailUrl: String
)


@OptIn(ExperimentalCoilApi::class)
@Composable
fun VideoItem(video: VideoItem, onItemClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick() }
            .border(4.dp, Color.Black)
    ) {
        Image(
            painter = rememberImagePainter(video.thumbnailUrl),
            contentDescription = "",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = video.title, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun VideoList(navController: NavController) {
    var videos by remember { mutableStateOf(emptyList<VideoItem>()) }

    LaunchedEffect(Unit) {
        fetchVideos { fetchedVideos ->
            videos = fetchedVideos
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn {
            items(videos) { video ->
                VideoItem(video = video) {
                    navController.navigate("video/${video.videoId}")
                }
            }
        }
    }
}

@Composable
fun VideoPlayerScreen(videoId: String) {
    YoutubeScreen(videoId = videoId, modifier = Modifier.fillMaxSize())
}

@Composable
fun AppContent(navController: NavController) {
    NavHost(navController = navController as NavHostController, startDestination = "videoList") {
        composable("videoList") { VideoList(navController) }
        composable(
            "video/{videoId}",
            arguments = listOf(navArgument("videoId") { type = NavType.StringType })
        ) { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId")
            videoId?.let { VideoPlayerScreen(videoId = it) }
        }
    }
}


private suspend fun fetchVideos(onVideosFetched: (List<VideoItem>) -> Unit) {
    withContext(Dispatchers.IO) {
        try {
            val youtube = YouTube.Builder(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                null
            ).setApplicationName("Your Application Name").build()

            val searchListResponse: SearchListResponse = youtube.search().list("snippet").apply {
                key = "AIzaSyCrsQ6YD5K7Pmu0j3rLobBWja6mz9z3KzE"//Your Api key
                type = "video"
                maxResults = 10 // Number of videos to fetch
                channelId = "UCpqXJOEqGS-TCnazcHCo0rA"
                order = "date"
            }.execute()

            val videos = searchListResponse.items.map { video ->
                val videoId = video.id.videoId
                val title = video.snippet.title
                val description = video.snippet.description
                val thumbnailUrl = video.snippet.thumbnails.default.url
                VideoItem(videoId, title, description, thumbnailUrl)
            }

            // Invoke the callback with the fetched videos
            onVideosFetched(videos)
        } catch (e: GoogleJsonResponseException) {
            // Handle API request errors
            e.printStackTrace()
            onVideosFetched(emptyList())
        }
    }
}